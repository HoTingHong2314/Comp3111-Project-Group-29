# Unit Test Report

Generated from the final `main` branch on 23 November 2026 with Maven 3.9.9
and Java 24.0.1.

## Result

| Metric | Value |
|---|---:|
| Tests run | **65** |
| Failures | **0** |
| Errors | **0** |
| Skipped | **0** |
| Pass rate | **100%** |

Command:

```powershell
.\mvnw.cmd clean test
```

## Test suite summary

| Test class | Tests |
|---|---:|
| `BuyerFlowTest` | 4 |
| `MarketplaceRulesTest` | 6 |
| `LifecycleRulesTest` | 29 |
| `OfferRulesTest` | 6 |
| `PersistenceTest` | 5 |
| `ProfileRulesTest` | 4 |
| `ServiceCoverageTest` | 7 |
| `UtilityCoverageTest` | 4 |
| **Total** | **65** |

The suites cover buyer flows, listing rules, lifecycle transitions, Buy Now and
offer validation, profile rules, JSON persistence, service branches and utility
edge cases.

## Supporting evidence

The full Maven Surefire report is available at
[evidence/surefire-report.html](evidence/surefire-report.html).
