# Coverage Report

Generated from the final `main` branch on 23 November 2026 with Maven 3.9.9
and Java 24.0.1.

## Result

| Metric | Covered | Total | Coverage |
|---|---:|---:|---:|
| Instructions | 7,423 | 7,829 | **94.81%** |
| Branches | 791 | 992 | **79.74%** |

The Maven build enforces a minimum of **65% branch coverage** through the
JaCoCo `check` execution. The final branch result is **79.74%**, so the gate
passes.

## Coverage scope

The report measures the business logic, domain models, persistence layer and
shared utilities. JavaFX presentation/bootstrap classes are excluded from
automated coverage and were exercised through the screenshot harness:

- `com/hkust/marketplace/controllers/**`
- `MarketplaceApp`
- `SceneManager`
- `SessionManager`
- `BorrowLifecycleScheduler`

## Supporting evidence

- [Interactive JaCoCo report](evidence/jacoco/index.html)
- [Machine-readable CSV](evidence/jacoco/jacoco.csv)
